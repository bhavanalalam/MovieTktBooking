package com.sat.tmf.movietkt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sat.tmf.movietkt.service.UserService;

public class AdminController {
	@Controller
	@RequestMapping("/add")
	public class LoginController {

		@Autowired
		private UserService userService;

		@GetMapping
		public String showLoginPage(Model model) {
			model.addAttribute("pageTitle", "addMovie");
			model.addAttribute("contentPage", "/WEB-INF/views/admin/layout/addMovie.jsp");
			return "layout/layout";
		}
	}
}
