package com.sat.tmf.movietkt.controller;

import com.sat.tmf.movietkt.entities.User;
import com.sat.tmf.movietkt.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private UserService userService;


    @GetMapping
    public String showLoginPage(Model model) {
        model.addAttribute("pageTitle", "Login");
        model.addAttribute("contentPage", "/WEB-INF/views/login.jsp");
        return "layout/layout";
    }


    @PostMapping
    public String processLogin(
            @RequestParam("username") String username,
            @RequestParam("password") String password,
            HttpSession session,
            Model model) {

     
        User user = userService.findByUsername(username);

        if (user != null && user.getPassword().equals(password)) {
            session.setAttribute("loggedInUser", user);
            model.addAttribute("message", "Welcome, " + user.getUsername() + "!");
            model.addAttribute("pageTitle", "Movies");
            model.addAttribute("contentPage", "/WEB-INF/views/movies.jsp");
            return "layout/layout";
        } else {
            model.addAttribute("error", "Invalid username or password!");
            model.addAttribute("pageTitle", "Login");
            model.addAttribute("contentPage", "/WEB-INF/views/login.jsp");
            return "layout/layout";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}